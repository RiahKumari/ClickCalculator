# React TODO Flummox

Obligatory React TODO demo using [Flummox](https://github.com/acdlite/flummox). A work in progress. 

[Demo](http://bradleyboy.github.io/react-todo-flummox/)

![Demo GIF](/screencap.gif?raw=true "Demo GIF")

## Usage

Based on [YARSK](https://github.com/bradleyboy/yarsk), see the [full readme](https://github.com/bradleyboy/yarsk#yarsk) there for how to use the various commands available. To get started, clone this repo then run:

```
npm install
npm run serve
```

That will fire up a webpack dev server in **hot** mode. Most changes will be reflected in the browser automatically without a browser reload. You can view the app in the browser at `http://localhost:8080`.
